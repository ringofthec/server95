package org.keplerproject.luajava;

public class LuaUtil
{
	public static String LUAJAVA_LIB = "";
	public static void loadLibrary()
	{
		System.load(LUAJAVA_LIB);
	}
}
